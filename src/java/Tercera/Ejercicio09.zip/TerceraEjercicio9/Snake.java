/*
 */
package TerceraEjercicio9;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Snake extends Applet implements Runnable {

    public static final int TIEMPO = 300;
    Image imgCasilla;
    Serpiente serpiente;

    Image imagen;
    Graphics noseve;
    Thread animacion;

    public void init() {
        imagen = this.createImage(800, 800);
        noseve = imagen.getGraphics();
        this.setSize(800, 800);

        imgCasilla = getImage(getCodeBase(), "TerceraEjercicio9/Imagenes/casilla.png");
        serpiente = new Serpiente(imgCasilla);

    }

    public void start() {
        animacion = new Thread(this);
        animacion.start();
    }

    public void update(Graphics g) {
        paint(g);

    }

    public void paint(Graphics g) {
        //noseve.setColor(Color.GREEN);
        noseve.setColor(Color.DARK_GRAY);
        noseve.fillRect(0, 0, 800, 800);

        serpiente.paint(noseve, this);

        g.drawImage(imagen, 0, 0, this);

    }

    @Override
    public void run() {
        do {

            serpiente.update();
            repaint();

            try {
                Thread.sleep(TIEMPO);
            } catch (InterruptedException ex) {
                Logger.getLogger(Snake.class.getName()).log(Level.SEVERE, null, ex);
            }

        } while (true);
    }

    public boolean keyDown(Event ev, int tecla) {
        serpiente.cambiarDireccion(tecla);
        return true;
    }

}
