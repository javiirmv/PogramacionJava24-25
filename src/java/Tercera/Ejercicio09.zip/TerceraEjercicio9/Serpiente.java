/*
ArrayList de 10 eslanbones, paint,actualizar serpiente(actulizar eslabones) van tomando los valores del eslabon anterior;
 */
package TerceraEjercicio9;

import java.applet.Applet;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;

public class Serpiente {

    public static final int posX = 100;
    public static final int posY = 100;
    ArrayList<Eslabon> eslabones;

    public Serpiente(Image imagen) {
        eslabones = new ArrayList<Eslabon>();
        for (int i = 0; i < 10; i++) {
            eslabones.add(new Eslabon(imagen, 200 - (Eslabon.TAM * i), 100, Event.RIGHT));
        }
    }

    public void paint(Graphics g, Applet ap) {
        for (Eslabon eslabon : eslabones) {
            eslabon.paint(g, ap);
        }

    }

    public Eslabon primerEslabon() { //Conseguimos Primmer elemento de la lista; La cabeza;
        return eslabones.get(0);
    }

    public Eslabon ultimoEslabon() { //Conseguimos el ultimo elemento de la lista;
        return eslabones.get(eslabones.size() - 1);
    }

    public void cambiarDireccion(int nuevaDireccion) {
        primerEslabon().setDireccion(nuevaDireccion);//cambiamos la direccion del primer eslabon;
    }

    public void update(){ //actulizamos la direccion de la serpiente;
        for (Eslabon eslabon : eslabones) {
            eslabon.update();
        }
        
         for (int i = eslabones.size()-1; i > 0; i--) {
            eslabones.get(i).setDireccion(eslabones.get(i-1).getDireccion());
        }
    }
    
    


}
