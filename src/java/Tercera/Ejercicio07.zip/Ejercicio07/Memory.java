package Tercera.Ejercicio07;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;

public class Memory extends Applet {

    Image imagen;
    Graphics noseve;
    Image imagenes[];
    Image reverso;
    Casilla casillas[];

    Casilla l1;
    Casilla l2;
    
    public void init() {
        imagen = this.createImage(700, 800);
        noseve = imagen.getGraphics();

        reverso = getImage(getCodeBase(), "Tercera/Ejercicio07/donutsMatch/reverso.png");

        imagenes = new Image[8];
        casillas = new Casilla[16];
        for (int i = 0; i < imagenes.length; i++) {
            imagenes[i] = getImage(getCodeBase(), "Tercera/Ejercicio07/donutsMatch/img" + (i + 1) + ".png");
        }

        for (int i = 0; i < casillas.length; i++) {
            casillas[i] = new Casilla(Casilla.DIM * (i % 4), Casilla.DIM * (i / 4), imagenes[i % 8], reverso);
        }

        desordenar();

        this.setSize(700, 800);
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void desordenar() {
        for (int i = 0; i < 30; i++) {
            int r1 = (int) (Math.random() * casillas.length);
            int r2 = (int) (Math.random() * casillas.length);

            Point aux = new Point(casillas[r1].x, casillas[r1].y);
            casillas[r1].setPosition(casillas[r2].x,casillas[r2].y);
            casillas[r2].setPosition(aux.x, aux.y);
        }
    }

    public void paint(Graphics g) {
        noseve.setColor(Color.DARK_GRAY);
        noseve.fillRect(0, 0, 700, 800);

        for (int i = 0; i < casillas.length; i++) {
            casillas[i].paint(noseve, this);

        }

        g.drawImage(imagen, 0, 0, this);
    }

    public boolean mouseDown(Event e, int x, int y) {
        for (Casilla casilla : casillas) {
            if (casilla.contains(x, y)) {
                if (l1 == null){
                    l1 = casilla;
                } else if (l2 == null) {
                    l2 = casilla;
                } else {
                    l1 = casilla;
                    l2 = null;
                }
                casilla.setTapada(false);
                repaint();
            }
        }
        return true;
    }

    public boolean mouseDrag(Event e, int x, int y) {

        return true;
    }

    public boolean mouseUp(Event e, int x, int y) {

        return true;
    }

    public boolean action(Event e, Object obj) {

        return true;
    }
}
