package Tercera.Ejercicio07;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

public class Casilla extends Rectangle {

    Image imagen;
    Image reverso;
    boolean tapada;

    public static final int DIM = 150;

    public Casilla(int x, int y, Image imagen, Image reverso) {
        super(x, y, DIM, DIM);
        this.imagen = imagen;
        this.reverso = reverso;
        this.tapada = true;

    }

    public void paint(Graphics g, Applet a) {
        if (tapada) {
            g.drawImage(reverso, x, y, DIM, DIM, a);

        } else {
            g.drawImage(imagen, x, y, DIM, DIM, a);

        }
    }
    
    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
    }

    public void setTapada(boolean tapada) {
        if (tapada) {
            this.tapada = true;
        } else {
            this.tapada = false;
        }
    }

}
